type LogoFacturappProps = {
  variant?: "icon" | "full";
  size?: number;
  className?: string;
};

export default function LogoFacturapp({ variant = "full", size = 44, className = "" }: LogoFacturappProps) {
  return (
    <span className={`facturapp-logo ${className}`.trim()} role="img" aria-label="Facturapp">
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
        <rect x="1" y="1" width="46" height="46" rx="9" fill="#0072BB" />
        <path d="M14 10.5H27L34 17.5V35.5C34 36.6 33.1 37.5 32 37.5H14C12.9 37.5 12 36.6 12 35.5V12.5C12 11.4 12.9 10.5 14 10.5Z" fill="white" />
        <path d="M27 10.5V17.5H34M17 22H28M17 26H25" stroke="#0072BB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="31.5" cy="31.5" r="8.5" fill="#10B981" />
        <path d="M27.5 31.5L30.2 34.2L35.5 28.8" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      {variant === "full" && <span className="facturapp-logo-copy"><strong>Facturapp</strong><small>Facturación electrónica</small></span>}
    </span>
  );
}
